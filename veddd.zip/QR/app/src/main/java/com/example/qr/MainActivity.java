package com.example.qr;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.TextView;
import android.widget.Toast;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.android.material.snackbar.Snackbar;
import com.google.zxing.Result;

public class MainActivity extends AppCompatActivity {
    private CodeScanner CodeScanner;
    private CodeScannerView CodeScannerView;
    private TextView resultView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if ((ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED)){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 123);
        }
        else{
            startScanning();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 123){
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"Permission Granted", Toast.LENGTH_SHORT).show();
                startScanning();
            }else {
                Toast.makeText(this,"Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startScanning() {
        CodeScannerView = findViewById(R.id.scanner_view);
        CodeScanner = new CodeScanner(this, CodeScannerView);

        CodeScanner.startPreview();//sluzi za scannanje coda, bez ovoga samo blank screen
        CodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull Result result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        resultView = findViewById(R.id.textResultView);
                        resultView.setText(result.getText());
                        resultView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if(URLUtil.isValidUrl(result.getText()))
                                {
                                    Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse(result.getText()));
                                    startActivity(web);
                                }
                                else{
                                    showToast();
                                }
                            }
                        });
                    }
                });
            }
        });
        // ako zelis ponovo scannat sa clickom
        CodeScannerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CodeScanner.startPreview();
            }
        });
    }

    private void showToast() {
        Toast.makeText(this, "Url is not valid", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        CodeScanner.startPreview();
    }

    @Override
    protected void onPause() {
        super.onPause();
        CodeScanner.releaseResources();
    }
}