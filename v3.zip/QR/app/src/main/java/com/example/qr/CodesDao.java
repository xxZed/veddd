package com.example.qr;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import java.util.List;

@Dao
public interface CodesDao{
    @Query("SELECT * FROM Codes")
    List<Codes> getAll();//dobiva listu stringova iz tablice Codes koja se nalazi u Codes.java

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(Codes... codes);//inserta Codes objekt koji sadrzi autoincrement id i string od scana

}
