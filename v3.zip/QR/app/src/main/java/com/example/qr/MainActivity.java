package com.example.qr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.room.Room;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.zxing.Result;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private CodeScanner CodeScanner;
    private TextView resultView;
    private final Codes localCodes = new Codes(); //classa Codes koju je potrebno instancirat ovako
    private AppDatabase db;
    private List<Codes> codesDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = AppDatabase.getInstance(this);//ovdje se baza creata ako ne postoji ako postoji dobiva bazu

        if ((ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED)){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 123);
        }
        else{
            startScanning();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 123){
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"Permission Granted", Toast.LENGTH_SHORT).show();
                startScanning();
            }else {
                Toast.makeText(this,"Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startScanning() {
        com.budiyev.android.codescanner.CodeScannerView codeScannerView = findViewById(R.id.scanner_view);
        CodeScanner = new CodeScanner(this, codeScannerView);

        CodeScanner.startPreview();//sluzi za scannanje coda, bez ovoga samo blank screen
        CodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull Result result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        saveData(result);//prosljedujemo result oblika Result
                        resultView = findViewById(R.id.textResultView);
                        resultView.setText(result.getText());//textView ispod CodeScannerView je clickable
                        resultView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if(URLUtil.isValidUrl(result.getText()))//provjera je li URL validan
                                {
                                    Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse(result.getText()));//ako je validan otvara web
                                    startActivity(web);
                                }
                                else{
                                    resultView.setText(result.getText());//ako nije podstavljamo text sa result.gettext i pocnemo ponovo previewat
                                    CodeScanner.startPreview();
                                }
                            }
                        });
                    }
                });

            }
        });
        // ako zelis ponovo scannat sa clickom
        codeScannerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CodeScanner.startPreview();
            }
        });
    }

    private void saveData(Result result) {
        localCodes.setScanString(result.getText());// class Codes sadrzi uid i scanString, qr code spremimo sa setScanString u LOKALNOJ classi oblika Codes.java
        db.codesDao().insertAll(localCodes);//Prosljedimo localCodes bazi podataka koja calla @Insert iz CodesDao.java interfaca i koja sprema u @Entity Codes.java
    }

    private void loadData(){
        LinearLayout ll = (LinearLayout) this.findViewById(R.id.linearview);//trazi linear layout
        ll.removeAllViews();
        codesDao = db.codesDao().getAll();// interface @query naredba koja se pristupa AppDatabase -> CodesDao -> Codes.java odakle izvlaci podatke
        for (Codes c: codesDao
             ) {
            TextView tv = new TextView(this);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            tv.setTextColor(Color.parseColor("#FFFFFFFF"));
            tv.setText(c.getScanString());
            ll.addView(tv);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        CodeScanner.startPreview();
    }
    @Override
    protected void onPause() {
        super.onPause();
        CodeScanner.releaseResources();
    }
    public void showHistory(View view) {
        loadData();
    }
}