package com.example.qr;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Codes.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public static AppDatabase appDatabase;
    public static String DATABASE_NAME = "qrHistory";
    public synchronized static AppDatabase getInstance(Context context){ // createa database ako je null ako nije vraca appDatabase
        if(appDatabase == null){
            appDatabase = Room.databaseBuilder(context.getApplicationContext(),
                    AppDatabase.class, DATABASE_NAME)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return appDatabase;
    }

    public abstract CodesDao codesDao();// interface za pristupanje Codes tablici sa @query i @insert
}
