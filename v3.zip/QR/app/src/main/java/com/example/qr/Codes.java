package com.example.qr;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Codes")
public class Codes {
    @PrimaryKey(autoGenerate = true) //autoincrement radi svaki put kada se scanString spremi
    public int uid;

    @ColumnInfo(name = "text")
    public String scanString;//sprema string scana koji dobiva

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getScanString() {
        return scanString;
    }

    public void setScanString(String scanString) {//dobiva string scana iz MainActivitya te sprema u @ColumnInfo scanString
        this.scanString = scanString;
    }
}
